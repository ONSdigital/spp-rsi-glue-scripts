import json
from botocore.exceptions import ClientError
import boto3
from botocore.client import Config

glue_client = boto3.client('glue', region_name='eu-west-2')


def handler(event, context):
    print("Starting Glue Crawler")
    class CrawlerException(Exception):
        pass

    try:
        response = glue_client.start_crawler(Name = 'spp_res_glu_business_survey_crawler')
        return {'crawler_name' : 'spp_res_glu_business_survey_crawler'}
    except ClientError as e:
        if e.response.get('Error', {}).get('Code') == 'CrawlerRunningException':
            print('crawler is running')
            return {'crawler_name' : 'spp_res_glu_business_survey_crawler'}
        else:
            raise
    except Exception as e:
        print('Problem while invoking crawler')
